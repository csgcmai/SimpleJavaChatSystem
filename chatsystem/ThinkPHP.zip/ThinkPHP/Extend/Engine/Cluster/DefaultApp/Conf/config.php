<?php
return array(
	//'配置项'=>'配置值'
	'SHOW_PAGE_TRACE'=>true,
	'URL_HTML_SUFFIX'=>'.html'
);
?>
